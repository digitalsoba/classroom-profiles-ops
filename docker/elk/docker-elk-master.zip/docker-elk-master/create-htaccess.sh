#!/bin/bash
htpasswd -c ./nginx/htpasswd.users $1 